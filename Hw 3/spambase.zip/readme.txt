spambase.data should be in same folder as both .py files
part 3 will show plot, and then data upon closure